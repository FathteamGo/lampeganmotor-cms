<?php

return[
     'reject_request' => 'Reject Request',
     'reject_reason'  => 'Reject Reason',
];