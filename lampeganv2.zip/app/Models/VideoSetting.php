<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VideoSetting extends Model
{
    protected $fillable = [
        'youtube_url',
    ];
}
