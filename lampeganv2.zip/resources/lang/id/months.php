<?php

return [
    'jan' => 'Jan',
    'feb' => 'Feb',
    'mar' => 'Mar',
    'apr' => 'Apr',
    'may' => 'Mei',
    'jun' => 'Jun',
    'jul' => 'Jul',
    'aug' => 'Agu',
    'sep' => 'Sep',
    'oct' => 'Okt',
    'nov' => 'Nov',
    'dec' => 'Des',
];
