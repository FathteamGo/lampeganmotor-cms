<?php

namespace App\Filament\Resources\Favicons\Pages;

use App\Filament\Resources\Favicons\FaviconResource;
use Filament\Resources\Pages\EditRecord;

class EditFavicon extends EditRecord
{
    protected static string $resource = FaviconResource::class;
}
