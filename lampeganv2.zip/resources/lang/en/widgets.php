<?php

return [
    'revenue_info' => 'Revenue Information',
    'revenue'      => 'Revenue',
    'this_month'   => 'This Month',
    'last_month'   => 'Last Month',
    'sales_statistics' => 'Sales Statistics',
    'sales'            => 'Sales',
];
