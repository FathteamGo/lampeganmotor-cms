<div class="flex items-center">
    @livewire('language-switcher')
</div>