<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Contact Information
    |--------------------------------------------------------------------------
    |
    |
    */

    'whatsapp' => env('WHATSAPP_NUMBER', '6281394510605'), // Ambil dari .env, jika tidak ada, gunakan nomor lama sebagai fallback

];
