<?php

namespace App\Filament\Resources\OtherAssets\Pages;

use App\Filament\Resources\OtherAssets\OtherAssetResource;
use Filament\Resources\Pages\CreateRecord;

class CreateOtherAsset extends CreateRecord
{
    protected static string $resource = OtherAssetResource::class;
}
