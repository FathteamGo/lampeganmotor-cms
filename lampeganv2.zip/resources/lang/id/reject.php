<?php 

return [
     'reject_request' => 'Permintaan ditolak',
     'reject_reason'  => 'Alasan Ditolak',
];