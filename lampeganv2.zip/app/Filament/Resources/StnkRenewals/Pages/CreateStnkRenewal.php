<?php

namespace App\Filament\Resources\StnkRenewals\Pages;

use App\Filament\Resources\StnkRenewals\StnkRenewalResource;
use Filament\Resources\Pages\CreateRecord;

class CreateStnkRenewal extends CreateRecord
{
    protected static string $resource = StnkRenewalResource::class;
}
