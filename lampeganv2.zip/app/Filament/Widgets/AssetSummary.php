<?php
namespace App\Filament\Widgets;

use Filament\Widgets\Widget;

class AssetSummary extends Widget
{
    protected string $view = 'filament.widgets.asset-sumary';
}
