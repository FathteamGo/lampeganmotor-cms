<?php

return [
    'revenue_info' => 'Informasi Pendapatan',
    'revenue'      => 'Pendapatan',
    'this_month'   => 'Bulan Ini',
    'last_month'   => 'Bulan Lalu',
    'sales_statistics' => 'Statistik Penjualan',
    'sales'            => 'Penjualan',
];
