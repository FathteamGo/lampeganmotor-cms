<?php

namespace App\Filament\Pages;

use Carbon\Carbon;
use Filament\Forms\Components\DatePicker;
use Filament\Pages\Dashboard as BaseDashboard;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Schema;

class Dashboard extends BaseDashboard
{
    use BaseDashboard\Concerns\HasFiltersForm;

  public function filtersForm(Schema $schema): Schema
{
     return $schema
        ->components([
            Section::make()
                ->schema([
                    DatePicker::make('startDate')
                        ->label(fn () => __('dashboard.start_date'))
                        ->default(Carbon::now()) // default ke hari ini
                        ->maxDate(fn (Get $get) => $get('endDate') ?: Carbon::now()),

                    DatePicker::make('endDate')
                        ->label(fn () => __('dashboard.end_date'))
                        ->default(Carbon::now()) // default ke hari ini
                        ->minDate(fn (Get $get) => $get('startDate') ?: Carbon::now())
                        ->maxDate(Carbon::now()),
                ])
                ->columns(3)
                ->columnSpanFull(),
        ]);
}

    public function getWidgets(): array
    {
        return [
            \App\Filament\Widgets\DashboardStats::class,
            \App\Filament\Widgets\VisitorStats::class,
            \App\Filament\Widgets\RevenueChart::class,
            \App\Filament\Widgets\SalesChart::class,
        ];
    }
}